//
//  PlaySoundsViewController.swift
//  PitchPerfect
//
//  Created by Melanie Cummings on 9/21/16.
//  Copyright © 2016 Melanie Cummings. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController{
    
    @IBOutlet weak var echoButton: UIButton!
    @IBOutlet weak var reverbButton: UIButton!
    @IBOutlet weak var darthButton: UIButton!
    @IBOutlet weak var chipmunkButton: UIButton!
    @IBOutlet weak var snailButton: UIButton!
    @IBOutlet weak var rabbitButton: UIButton!
    @IBOutlet weak var stopPlayingButton: UIButton!
    
    @IBOutlet weak var stackMain: UIStackView!
    @IBOutlet weak var firstStack: UIStackView!
    @IBOutlet weak var secondStack: UIStackView!
    @IBOutlet weak var thirdStack: UIStackView!
    @IBOutlet weak var fourthStack: UIStackView!
    
    var recordedAudioURL: URL!
    var audioFile: AVAudioFile!
    var audioEngine: AVAudioEngine!
    var audioPlayerNode: AVAudioPlayerNode!
    var stopTimer: Timer!
    
    enum ButtonType: Int {case fast = 0, slow, chipmunk, darth, reverb, echo}
    
    @IBAction func playSoundForButton(_ sender: UIButton){
        print("Playback button was pressed and function called")
        switch ButtonType(rawValue:sender.tag)! {
        case .fast:
            playSound(rate:1.5)
        case .slow:
            playSound(rate:0.5)
        case .chipmunk:
            playSound(pitch:1000)
        case .darth:
            playSound(pitch:-1000)
        case .reverb:
            playSound(reverb:true)
        case .echo:
            playSound(echo:true)
        }
        configureUI(.playing)
    }
    
    @IBAction func stopButtonPressed(_ sender: AnyObject) {
        stopAudio()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        snailButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        echoButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        reverbButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        darthButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        chipmunkButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        rabbitButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        stopPlayingButton.imageView?.contentMode = UIViewContentMode.scaleAspectFit
        
        setupAudio()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        configureUI(.notPlaying)
        
    }
    
        

}
