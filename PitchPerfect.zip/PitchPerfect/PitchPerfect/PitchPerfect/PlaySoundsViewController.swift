//
//  PlaySoundsViewController.swift
//  PitchPerfect
//
//  Created by Melanie Cummings on 9/21/16.
//  Copyright © 2016 Melanie Cummings. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController {
    
    @IBOutlet weak var echoButton: UIButton!
    @IBOutlet weak var reverbButton: UIButton!
    @IBOutlet weak var darthButton: UIButton!
    @IBOutlet weak var chipmunkButton: UIButton!
    @IBOutlet weak var snailButton: UIButton!
    @IBOutlet weak var rabbitButton: UIButton!
    @IBOutlet weak var stopPlayingButton: UIButton!
    
    var recordedAudioURL: NSURL!
    var audioFile: AVAudioFile!
    var audioEngine: AVAudioEngine!
    var audioPlayerNode: AVAudioPlayerNode!
    var stopTimer: NSTimer!
    
    enum ButtonType: Int {case Fast = 0, Slow = 1, Chipmunk = 2, Darth = 3, Reverb = 4, Echo = 5}
    
    @IBAction func playSoundForButton(sender: UIButton){
        print("Playback button was pressed and function called")
        switch ButtonType(rawValue:sender.tag)! {
        case .Fast:
            playSound(rate:1.5)
        case .Slow:
            playSound(rate:0.5)
        case .Chipmunk:
            playSound(pitch:1000)
        case .Darth:
            playSound(pitch:-1000)
        case .Reverb:
            playSound(reverb:true)
        case .Echo:
            playSound(echo:true)
        }
        
        configureUI(.Playing)
            
        
    }
    
    @IBAction func stopButtonPressed(sender: AnyObject) {
        print("Stop button was pressed and function called")
        stopAudio()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("PlaySoundsViewController is loaded")
        setupAudio()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(animated: Bool) {
        configureUI(.NotPlaying)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  

}
